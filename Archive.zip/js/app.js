//var bug1, bug2;
var Enemy = function() {
    // The image/sprite for our enemies, this uses
    // a helper we've provided to easily load images
    var bug = Object.create(Enemy.prototype);
    this.sprite = 'images/enemy-bug.png';
// I added in this.start() because I wanted to make the starting locations of
// the enemies random and so that I could reuse enemies after they had crossed
// the screen. To do this I added an if (x > 606) {x-700} to the move function
    this.start();
    return this;
};
Enemy.prototype.start = function () {
  //picks a random number between 0 and -10 and multiplies by 101 as the
  //starting x coordinate
  this.x = (Math.random() * (- 1 + 10) - 10) * 101;
  //and between 1 and 4 (for row # from bottom to top incl. 0) and multiplies
  // by 86 for the starting y coordinate
  this.y = (Math.random() * (4 - 1 + 1) + 1) * 86;
};
//was attempting to make bugs move diagonally, this makes them jitter, also cool
Enemy.prototype.deltaY = function () {
  //returns -1 or 1 every game loop
  deltaY = Math.random() < 0.5 ? -1 : 1;
  return deltaY;
};
Enemy.prototype.update = function(dt) {
    if (this.x > 505) {
      this.start();
    } else {
    player.score();
    this.x += (enemySpeed * dt);
    //40-423
    if (this.y > 40 && this.y < 423) {
      this.y += (this.deltaY() * 0.3 * enemySpeed * dt);
    } else if (this.y < 41) {
      this.y === 42;
    } else if (this.y > 422) {
      this.y === 421;
    }
    //collision detection
    if (player.x > (this.x - 40) && player.x < (this.x + 70)) {
      if (player.y < (this.y + 20) && player.y > (this.y - 50)) {
        player.start();
        player.loss();
      }
    }
  }
};
Enemy.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

// ----- TODO: get EnemyReverse sprite to show up ---------
var EnemyReverse = function() {
  var bugReverse = Object.create(EnemyReverse.prototype);
  this.sprite = 'images/enemy-bug-reverse.png';
  this.start();
};
EnemyReverse.prototype.update = function(dt) {
  if (this.x < -101) {
    this.start();
  } else {
  player.score();
  this.x -= (enemySpeed * dt);
  }
  if (this.y > 40 && this.y < 423) {
    this.y += (this.deltaY() * 0.3 * enemySpeed * dt);
  } else if (this.y < 41) {
    this.y === 42;
  } else if (this.y > 422) {
    this.y === 421;
  }
  //collision detection
  if (player.x > (this.x - 40) && player.x < (this.x + 70)) {
    if (player.y < (this.y + 20) && player.y > (this.y - 50)) {
      player.start();
      player.loss();
    }
  }
};
EnemyReverse.prototype.start = function () {
  //picks a random number between 0 and -10 and multiplies by 101 as the
  //starting x coordinate
  this.x = (Math.random() * (5 - 15) + 15) * 101;
  //and between 1 and 4 (for row # from bottom to top incl. 0) and multiplies
  // by 86 for the starting y coordinate
  this.y = (Math.random() * (4 - 1 + 1) + 1) * 86;
};
//was attempting to make bugs move diagonally, this makes them jitter, also cool
EnemyReverse.prototype.deltaY = function () {
  //returns -1 or 1 every game loop
  deltaY = Math.random() < 0.5 ? -1 : 1;
  return deltaY;
};
EnemyReverse.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

var Player = function () {
  this.sprite = "images/char-horn-girl.png";
  this.start();
};

Player.prototype.score = function () {
 score += 0.05 * (wins + 1);
 document.querySelector('#score').innerHTML = "Your score is " +
 Math.floor(score) + ".";
};
Player.prototype.start = function () {
  this.x = 200;
  this.y = 400;
};
Player.prototype.update = function () {

};
Player.prototype.win = function() {
  wins += 1;
  var bonus = 1000;
  score += bonus;
  resetX();

  document.querySelector("#level").innerHTML = "Level " + (wins + 1);
  document.querySelector("#wins").innerHTML = "Your win count is: " + wins;
  if (confirm("Congratulations, you have reached safety! +" + bonus +
    " points! \n \n" + "Do you want to play the next level?")) {
    this.start();
    if (wins === 1) {
      enemySpeed += 50;
      var bug3 = new EnemyReverse();
      allEnemiesReverse.push(bug3);
    } else if (wins === 2) {
      enemySpeed += 50;
      var bug4 = new EnemyReverse();
      allEnemiesReverse.push(bug4);
    } else if (wins === 3) {
      enemySpeed += 50;
      var bug5 = new Enemy();
      allEnemies.push(bug5);
    } else if (wins === 6) {
      var bug6 = new EnemyReverse();
      allEnemiesReverse.push(bug6);
    } else if (wins > 6 && wins % 2 === 0) {
      var bug7 = new Enemy();
      allEnemies.push(bug7);
    } else if (wins > 7 && wins % 2 === 1) {
      var bug8 = new EnemyReverse();
      allEnemiesReverse.push(bug8);
    }
  } else {
    // TODO find way to close out game
    this.enterHallOfFame();
  }
};
Player.prototype.loss = function () {
  var penalty  = 2000;
  score -= penalty;
  losses += 1;
  resetX();

  document.querySelector("#losses").innerHTML = "Your loss count is: " +
   losses;
  if (confirm("Your charachter was eaten! -" + penalty + " points! :( \ \n" +
    "Play again?")) {
    //why is player.start always in red!??!?! its a function
    player.start();
  } else {
    player.enterHallOfFame();
  }
};
Player.prototype.enterHallOfFame = function () {
  var name = prompt("Please enter your name to be added to the hall of fame." +
  "\n Thank you for playing. Have a nice day!", "");
  this.start();
  var newRecord = {
    "Name" : name,
    "High Score" : Math.floor(score),
    "Wins" : wins,
    "Losses" : losses
  };
  hallOfFame.push(newRecord);
  //alert(table(hallOfFame));
  player.newGame();

};
Player.prototype.render = function () {
  ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};
Player.prototype.newGame = function(){
  score === 0;
  wins === 0;
  losses === 0;
  resetX();
};

Player.prototype.handleInput = function (e) {
  //handles arrow key inputs to move player around canvas
  if (e === 37) {
    //prevents player from going off of screen
    if (player.x < 51) {
      player.x = 0;
    } else {
    player.x -= 50;
    }
  } else if (e === 38) {
    //prevents player from going off of screen
    if (player.y < 40) {
      this.win();
    } else {
    player.y -= 43;
    }
  } else if (e === 39) {
    //prevents player from going off of screen
    if (player.x > 399) {
      player.x = 400;
    } else {
    player.x += 50;
    }
  } else if (e === 40) {
    //prevents player from going off of screen
    if (player.y > 380) {
      player.y = 423;
    } else {
    player.y += 43;
    }
  }
};
var resetX = function() {
  allEnemies.forEach(function(enemy){
    enemy.x = (Math.random() * (- 1 + 10) - 10) * 101;
  });
  allEnemiesReverse.forEach(function(enemyRev){
    enemyRev.x = (Math.random() * (5 - 15) - 15) * 101;
  });
};

var hallOfFame = [];
var allEnemies = [];
var allEnemiesReverse = [];
var score = 0;
var wins = 0;
var losses = 0;
var enemySpeed = 100;
var level = 1;
var bug1 = new Enemy();
var bug2 = new Enemy();
allEnemies.push(bug1, bug2);
var player = new Player();

document.addEventListener('keyup', function(e) {
    player.handleInput(e.keyCode);
});
